import java.util.Scanner;

class Arr
{
	public static void main(String args[])
	{
		Scanner input=new Scanner(System.in);
		int a1[]=new int[20];
		int sum=0,i,len;
		System.out.print("Enter the length of array : ");
		len=input.nextInt();
		System.out.print("Enter the elements array : ");
		for(i=0;i<len;i++)
		{
			a1[i]=input.nextInt();
			sum=sum+a1[i];
		}		
		System.out.print("Sum of array's Elements is : "+sum);
	}
}