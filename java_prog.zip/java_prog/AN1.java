class AN1
{
public static void main(String[]args)
{
if(a<=100||b>=80)
{
System.out.println("Grade A");
}
else if(a<=80||b>=60)
{
System.out.println("Grade B");
}
else if(a<=60||b>=40)
{
System.out.println("Grade C");
}
else
{
System.out.println(Grade D");
}}}