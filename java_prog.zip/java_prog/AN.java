class NA
{
public static void main(String[]args)
{
int x=60;
System.out.println(x%2=0)?("even"):("odd");
}}



