import java.util.Scanner;

class While_loop
{
	public static void main(String args[])
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the number : ");
		int n=input.nextInt();
		int x=0,sum=0;
		for(int i=1;i<=10;i++)
		{
			if(n%5==0)
			{
				x=n;
				break;
			}
			n++;
		}
		sum=x;
		for(int i=2;i<=10;i++)
		{
			System.out.println(x+"  ");
			x=x+5;
			sum=sum+x;
		}
		System.out.println("Sum : "+sum);
	}
}