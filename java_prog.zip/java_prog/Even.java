class Even
{
public static void main(String[]args)
{
int x=40;
int y=x%2;
if(y==0)
{
System.out.println("Number is even");
}
else
{
System.out.println("Number is odd");
}
}
}
