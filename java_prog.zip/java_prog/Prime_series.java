import java.util.Scanner;

class Prime_series
{
	public static void main(String args[])
	{
		Scanner input=new Scanner(System.in);
		int n,i,j;
		System.out.print("Enter the range upto you want to print Prime number :  ");
		n=input.nextInt();
		
		for(i=2;i<=n;i++)
		{
			for(j=2;j<i-1;j++)
			{
				if((i%j)==0)
				{
					break;					
				}
				else
				{
						if(j==i+1)
						{
							System.out.print(i);
						}					
				}
			}
		}
	}
}