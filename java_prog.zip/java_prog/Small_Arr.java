import java.util.Scanner;

class Small_Arr
{
	public static void main(String args[])
	{
		Scanner input=new Scanner(System.in);
		int a[]=new int[20];
		int i,small,len;
		System.out.print("Enter the length of array : ");
		len=input.nextInt();
		System.out.print("Enter the elements array : ");
		for(i=0;i<len;i++)
		{
			a[i]=input.nextInt();
		}
		small=a[0];
		for(i=0;i<len;i++)
		{
			if(a[i]<small)
			{
				small=a[i];
			}
		}
		System.out.print("Smallest element of array is : "+small);
	}
}