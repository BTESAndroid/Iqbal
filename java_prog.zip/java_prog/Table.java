import java.util.Scanner;
class Table
{
	public static void main(String args[])
	{
		Scanner input=new Scanner(System.in);
		System.out.print("Enter the number to print the table : ");
		int n=input.nextInt();
		int i=1;
		while(i<=10)
		{
			System.out.println(n+" * "+i+" = "+n*i );
			i++;
		}
	}
	
}