//WAP to check whether a number is Armstrong or not..!!
import java.util.Scanner;

class Armstrong
{
	public static void main(String args[])
	{
		Scanner input=new Scanner(System.in);
		int n,i,digit,sum=0,num;
		System.out.print("Enter the number : ");
		n=input.nextInt();
		num=n;
		while(n!=0)
		{
			digit=n%10;
			sum=sum+(digit*digit*digit);
			n=n/10;
		}
		if(sum==num)
		{
		System.out.print("Number is Armstrong..!!");		
		}
		else
		{
			System.out.print("Number is not Armstrong..!!");
		}
}
}