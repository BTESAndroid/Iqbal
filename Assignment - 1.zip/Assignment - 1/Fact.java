//WAP to find the factorial of the number
import java.util.Scanner;

class Fact
{
	public static void main(String args[])
	{
		Scanner input=new Scanner(System.in);
		int n,i,res;
		System.out.print("Enter the number : ");
		n=input.nextInt();
		res=n;
		for(i=n-1;i>=1;i--)
		{
			res=res*i;
		}
		System.out.println("Factorial is : "+res);
	}

}