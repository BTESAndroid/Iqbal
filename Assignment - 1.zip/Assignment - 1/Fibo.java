//WAP to print the Fibonacci series
import java.util.Scanner;

class Fibo
{
	public static void main(String args[])
	{
		int n,i,x=0,y=1,z=0;
		Scanner input=new Scanner(System.in);
		System.out.print("Enter the limit of number you want to print : ");
		n=input.nextInt();
		System.out.print(x+" "+y);
		for(i=2;i<n;i++)
		{
			z=x+y;
			x=y;
			y=z;
			System.out.print(" "+z);
		}

		
	}
}