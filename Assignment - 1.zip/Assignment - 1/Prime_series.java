//WAP to print the series of prime number from 1 to n
import java.util.Scanner;

class Prime_series
{
	public static void main(String args[])
	{
		Scanner input=new Scanner(System.in);
		int n,i,j,count=0;
		System.out.print("Enter the range upto you want to print prime number : ");
		n=input.nextInt();
		for(i=2;i<=n;i++)
		{
			for(j=2;j<i;j++)
			{
				if(i%j==0)
				{
					break;
				}
				else
				{
					if(i==j+1)
					{
						System.out.println(i);	
					}
				}
			}
		}
	}

}