//WAP to find the HCF and LCM of two number
import java.util.Scanner;

class Hcf_Lcm
{
	public static void main(String args[])
	{
		Scanner input=new Scanner(System.in);
		int a,b,n,i,HCF=0,LCM=0;
		System.out.print("Enter the two Integer numbers : ");
		a=input.nextInt();
		b=input.nextInt();
		if(a>b)
		{
			n=a;
		}
		else
		{
			n=b;
		}
		for(i=n;i>=1;i--)
		{
			if(a%i==0 && b%i==0)
			{
				HCF=i;				
				break;
			}
		}
		LCM=(a*b)/HCF;
		System.out.print(HCF+" is the HCF of "+a+" & "+b);
		System.out.print("\n"+LCM+" is the LCM of "+a+" & "+b);
	}
}