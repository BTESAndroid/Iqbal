//WAP for Innovation of String..!!
class String_Inno
{
	public static void main(String arg[])
	{
		String str="Helloo .. Welcome to java..!!!";
		System.out.print(str);
	}
}