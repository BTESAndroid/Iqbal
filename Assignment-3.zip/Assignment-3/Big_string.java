import java.util.Scanner;
class Big_string
{
	public static void main(String arg[])
	{
		Scanner input=new Scanner(System.in);
		System.out.print("Enter the String : ");
		String s=input.nextLine();
		String[] s1=s.split(" ");
		int greatest=s1[0].length();
		int loc=0;
		for(int i=0;i<=s1.length-1;i++)
		{
			if(s1[i].length()>greatest)
			{
				greatest=s1[i].length();
				loc=i;
			}
		}
		System.out.println("Biggest substring of string is : "+s1[loc]);
	}
}