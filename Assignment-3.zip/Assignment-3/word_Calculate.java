//WAP to calculate the occurance of word in a string ..!!
import java.util.*;
class word_Calculate
{
	public static void main(String arg[])
	{
		Scanner input=new Scanner(System.in);
		int count=0,i;
		System.out.print("Enter the Sentence : ");
		String s1=input.nextLine();
		s1=s1.toLowerCase();
		System.out.print("Enter the word that you want to find in Sentence : ");
		String s2=input.next();
		String[] str=s1.split(" ");
		for(i=0;i<str.length;i++)
		{
			if(str[i].equals(s2))
			{
				count++;
			}
		}
		if(count==0)
		{
			System.out.print("No match found..!!!");
		}
		else
		{
			System.out.print("Word occured in the Sentence "+count+" times..!!");
		}
	}
}
