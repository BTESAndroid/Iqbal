//WAP to check whether to strings are anagram or not..!!
import java.util.*;
class Anagram_Str
{
	public static void main(String arg[])
	{
		Scanner input=new Scanner(System.in);
		System.out.print("Enter the 1st string : ");
		String s1=input.next();
		System.out.print("Enter the 2nd string : ");
		String s2=input.next();
		s1=s1.toLowerCase();
		s2=s2.toLowerCase();
		char[] arr1=s1.toCharArray();
		char[] arr2=s2.toCharArray();
		Arrays.sort(arr1);
		Arrays.sort(arr2);
		String str1=new String(arr1);
		String str2=new String(arr2);
		if(str1.equals(str2))
		{
			System.out.print("Strings are anagram..!!");
		}
		else
		{
			System.out.print("Strings are not anagram..!!");
		}
	
	}
}