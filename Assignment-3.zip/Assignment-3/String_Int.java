//WAP to convert numeric string into int ..
import java.util.*;
class String_Int
{
	public static void main(String arg[])
	{
		Scanner input=new Scanner(System.in);
		System.out.print("Enter the numeric string : ");
		String s1=input.next();
		System.out.println("Numeric String : "+s1);
		Integer data=Integer.parseInt(s1);	
		System.out.print("Integer type data : "+data);
	}
}