//WAP to make substring from occurance of duplicate values in string ..!!
import java.util.*;
class SubString_Dup
{
	public static void main(String arg[])
	{
		Scanner input=new Scanner(System.in);
		int count=0,j,i,found=0;
		System.out.print("Enter the string : ");
		String s1=input.nextLine();
		s1=s1.toLowerCase();
		char[] arr1=s1.toCharArray();
		char[] arr2=new char[40];
		for(i=0;i<arr1.length;i++)
		{
			for(j=0;j<arr1.length;j++)
			{
				if(arr1[i]==arr1[j])
				{
					count++;
				}
			}
			for(j=0;j<arr2.length;j++)
			{
				if(arr1[i]==arr2[j])
				{
					found++;
				}
			}
			if(count>1 && found==0)
			{
				arr2[i]=arr1[i];
				found=0;
			}
				count=0;
		}
		String str1=new String(arr1);
		String str2=new String(arr2);
		System.out.print("Real String : "+str1);
		System.out.print("\nSubstring containing duplicate values : "+str2);
	}
}
