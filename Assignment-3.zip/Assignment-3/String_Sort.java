//WAP to sorting a string using string API..!!
import java.util.*;
class String_Sort
{
	public static void main(String arg[])
	{
		Scanner input=new Scanner(System.in);
		System.out.print("Enter the 1st string : ");
		String s1=input.nextLine();
		char[] arr1=s1.toCharArray();
		Arrays.sort(arr1);
		String str1=new String(arr1);
		System.out.print("Sorted String is : "+str1);
	}
}