/*
WAP to print the number from 1 to 50 but for multiples of 3 print "Fizz" instead of the number 
and for the multiple of 5 print "Buzz" and for which is multiple of both 3 & 5 print "FizzBuzz"..!!
*/ 
class Multiple_print
{
	public static void main(String arg[])
	{
		for(int i=0;i<=50;i++)
		{
			if(i%3==0 && i%5==0)
			{
				System.out.println("FizzBuzz");
			}
			else if(i%3==0 || i%5==0)
			{
				if(i%3==0)
				{
					System.out.println("Fizz");
				}
				else
				{
					System.out.println("Buzz");
				}				
			}
			else
			{
				System.out.println(i);
			}
		}
	}
}